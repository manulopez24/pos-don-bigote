
const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const path = require('path');

const app = express();

app.use(cors());
app.use(express.json());

const JWT_SECRET = process.env.JWT_SECRET;
const JWT_EXPIRES = '12h';

if (!JWT_SECRET) {
    console.error('❌ Falta configurar JWT_SECRET en las variables de entorno.');
    process.exit(1);
}

// Conexión a MySQL de Hostinger
const pool = mysql.createPool({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    port: Number(process.env.DB_PORT || 3306),
    waitForConnections: true,
    connectionLimit: 15,
    queueLimit: 0
});

// Verificar conexión y liberar el recurso
pool.getConnection((err, conn) => {
    if (err) {
        console.error('❌ Error conectando a MySQL:', err.code || err.message);
        return;
    }

    console.log('✅ Conectado exitosamente a MySQL de Don Bigote!');
    conn.release();
});

// ── Middleware JWT ─────────────────────────────────────────────
function verificarToken(req, res, next) {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];
    if (!token) return res.status(401).json({ error: 'Token requerido.' });

    jwt.verify(token, JWT_SECRET, (err, usuario) => {
        if (err) return res.status(403).json({ error: 'Sesión expirada o token inválido.' });
        req.usuario = usuario;
        next();
    });
}

function verificarAdmin(req, res, next) {
    if (req.usuario.rol !== 'admin') {
        return res.status(403).json({ error: 'Acceso restringido. Solo el Administrador puede realizar esta acción.' });
    }
    next();
}

// ══════════════════════════════════════════════════════════════
// RUTAS DE LA API
// ══════════════════════════════════════════════════════════════

// 1. POST /api/login — Login
app.post('/api/login', (req, res) => {
    const { usuario, password } = req.body;
    if (!usuario || !password) return res.status(400).json({ error: 'Ingresa usuario y contraseña.' });

    const query = `SELECT id, nombre, usuario, password, rol, activo FROM usuarios WHERE usuario = ? LIMIT 1`;
    pool.query(query, [usuario], (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        if (!results || results.length === 0) return res.status(401).json({ error: 'Usuario no encontrado.' });

        const user = results[0];
        if (user.activo === 0 || user.activo === false) return res.status(403).json({ error: 'Usuario inactivo.' });
        if (password !== user.password) return res.status(401).json({ error: 'Contraseña incorrecta.' });

        const payload = { id: user.id, nombre: user.nombre, usuario: user.usuario, rol: user.rol };
        const token = jwt.sign(payload, JWT_SECRET, { expiresIn: JWT_EXPIRES });
        res.json({ message: 'Login exitoso', token, usuario: payload });
    });
});

// GET /api/mesas — Obtener estado visual de todas las mesas
app.get('/api/mesas', verificarToken, (req, res) => {
    pool.query(`SELECT id, nombre, estado FROM mesas ORDER BY id ASC`, (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results);
    });
});

// 2. GET /api/menu — Menú real desde MySQL
app.get('/api/menu', verificarToken, (req, res) => {
    const query = `
        SELECT p.id, p.nombre, p.precio, c.nombre as categoria
        FROM productos p
        JOIN categorias c ON p.categoria_id = c.id
        WHERE p.disponible = TRUE
        ORDER BY c.nombre, p.nombre
    `;
    pool.query(query, (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results);
    });
});

// 3. POST /api/pedidos — Guardar o AGREGAR a comanda abierta de mesa
app.post('/api/pedidos', verificarToken, (req, res) => {
    const { mesa_nombre, items, tipo_pedido = 'Mesa' } = req.body;
    if (!items || items.length === 0) return res.status(400).json({ error: 'Comanda vacía.' });

    const nuevoSubtotal = items.reduce((acc, i) => acc + (parseFloat(i.precio) * i.cantidad), 0);

    pool.query(`SELECT id FROM mesas WHERE nombre = ? LIMIT 1`, [mesa_nombre || 'Mesa 1'], (mErr, mRes) => {
        const mesaId = (mRes && mRes.length > 0) ? mRes[0].id : null;

        const checkOpenSQL = `
            SELECT id, total FROM pedidos 
            WHERE mesa_id = ? AND estado_global = 'Abierto' 
            LIMIT 1
        `;

        pool.query(checkOpenSQL, [mesaId], (cErr, cRes) => {
            if (!cErr && cRes && cRes.length > 0) {
                const pedidoExistenteId = cRes[0].id;
                const nuevoTotalCalculado = parseFloat(cRes[0].total) + nuevoSubtotal;

                const detallesValues = items.map(i => [pedidoExistenteId, i.id, i.cantidad, i.notas || '', 'Pendiente']);
                const insertDetallesSQL = `
                    INSERT INTO detalles_pedido (pedido_id, producto_id, cantidad, notas_cocina, estado_cocina)
                    VALUES ?
                `;

                pool.query(insertDetallesSQL, [detallesValues], (dErr) => {
                    if (dErr) return res.status(500).json({ error: dErr.message });
                    pool.query(`UPDATE pedidos SET total = ? WHERE id = ?`, [nuevoTotalCalculado, pedidoExistenteId]);
                    res.json({ message: 'Nuevos productos agregados a la comanda abierta', pedido_id: pedidoExistenteId });
                });

            } else {
                const insertPedidoSQL = `
                    INSERT INTO pedidos (tipo_pedido, mesa_id, nombre_cliente, estado_global, total)
                    VALUES (?, ?, ?, 'Abierto', ?)
                `;
                pool.query(insertPedidoSQL, [tipo_pedido, mesaId, req.usuario.nombre, nuevoSubtotal], (pErr, pRes) => {
                    if (pErr) return res.status(500).json({ error: pErr.message });
                    const pedidoId = pRes.insertId;

                    const detallesValues = items.map(i => [pedidoId, i.id, i.cantidad, i.notas || '', 'Pendiente']);
                    const insertDetallesSQL = `
                        INSERT INTO detalles_pedido (pedido_id, producto_id, cantidad, notas_cocina, estado_cocina)
                        VALUES ?
                    `;
                    pool.query(insertDetallesSQL, [detallesValues], (dErr) => {
                        if (dErr) return res.status(500).json({ error: dErr.message });
                        if (mesaId) pool.query(`UPDATE mesas SET estado = 'Ocupada' WHERE id = ?`, [mesaId]);
                        res.json({ message: 'Comanda enviada con éxito', pedido_id: pedidoId });
                    });
                });
            }
        });
    });
});

// 4. GET /api/mesero/mis-pedidos — Ver comandas activas del mesero y estado de cocina
app.get('/api/mesero/mis-pedidos', verificarToken, (req, res) => {
    const query = `
        SELECT 
            p.id as pedido_id,
            COALESCE(m.nombre, 'Llevar') as mesa,
            p.total,
            TIME_FORMAT(p.fecha_hora, '%H:%i') as hora,
            dp.id as detalle_id,
            pr.nombre as producto_nombre,
            dp.cantidad,
            dp.estado_cocina
        FROM pedidos p
        LEFT JOIN mesas m ON p.mesa_id = m.id
        JOIN detalles_pedido dp ON dp.pedido_id = p.id
        JOIN productos pr ON dp.producto_id = pr.id
        WHERE p.estado_global = 'Abierto' AND p.nombre_cliente = ?
        ORDER BY p.fecha_hora DESC, dp.id ASC
    `;

    pool.query(query, [req.usuario.nombre], (err, results) => {
        if (err) return res.status(500).json({ error: err.message });

        const misPedidosMap = {};
        results.forEach(row => {
            if (!misPedidosMap[row.pedido_id]) {
                misPedidosMap[row.pedido_id] = {
                    pedido_id: row.pedido_id,
                    mesa: row.mesa,
                    total: row.total,
                    hora: row.hora,
                    items: []
                };
            }
            misPedidosMap[row.pedido_id].items.push({
                detalle_id: row.detalle_id,
                nombre: row.producto_nombre,
                cantidad: row.cantidad,
                estado_cocina: row.estado_cocina
            });
        });

        res.json(Object.values(misPedidosMap));
    });
});

// 5. GET /api/cocina/pedidos — EXCLUIR GASEOSAS, BEBIDAS, CERVEZAS Y HELADOS DE COCINA
app.get('/api/cocina/pedidos', verificarToken, (req, res) => {
    const query = `
        SELECT 
            dp.id as detalle_id,
            p.id as pedido_id,
            COALESCE(m.nombre, 'Para Llevar') as mesa,
            p.nombre_cliente as mesero,
            TIME_FORMAT(p.fecha_hora, '%H:%i') as hora,
            pr.nombre as producto_nombre,
            dp.cantidad,
            dp.notas_cocina,
            dp.estado_cocina
        FROM detalles_pedido dp
        JOIN pedidos p ON dp.pedido_id = p.id
        JOIN productos pr ON dp.producto_id = pr.id
        JOIN categorias c ON pr.categoria_id = c.id
        LEFT JOIN mesas m ON p.mesa_id = m.id
        WHERE p.estado_global = 'Abierto' 
          AND dp.estado_cocina IN ('Pendiente', 'Preparando')
          AND c.nombre NOT IN ('Bebidas', 'Bebidas Frías', 'Cervezas', 'Helados')
        ORDER BY p.fecha_hora ASC, dp.id ASC
    `;
    pool.query(query, (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        const comandasMap = {};
        results.forEach(row => {
            if (!comandasMap[row.pedido_id]) {
                comandasMap[row.pedido_id] = {
                    id: row.pedido_id,
                    mesa: row.mesa,
                    mesero: row.mesero,
                    hora: row.hora,
                    items: []
                };
            }
            comandasMap[row.pedido_id].items.push({
                detalle_id: row.detalle_id,
                nombre: row.producto_nombre,
                cantidad: row.cantidad,
                notas: row.notas_cocina,
                estado_cocina: row.estado_cocina
            });
        });
        res.json(Object.values(comandasMap));
    });
});

// 6. PUT /api/cocina/detalles/:id/estado — Estado cocina
app.put('/api/cocina/detalles/:id/estado', verificarToken, (req, res) => {
    const { id } = req.params;
    const { estado } = req.body;
    pool.query(`UPDATE detalles_pedido SET estado_cocina = ? WHERE id = ?`, [estado, id], (err) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: 'Estado actualizado' });
    });
});

// 7. GET /api/caja/pedidos — Cuentas abiertas para Cajero
app.get('/api/caja/pedidos', verificarToken, (req, res) => {
    const query = `
        SELECT 
            p.id as pedido_id,
            COALESCE(m.nombre, 'Llevar/Delivery') as mesa,
            p.nombre_cliente as mesero,
            p.total,
            p.estado_global,
            TIME_FORMAT(p.fecha_hora, '%H:%i') as hora,
            JSON_ARRAYAGG(
                JSON_OBJECT(
                    'nombre', pr.nombre,
                    'cantidad', dp.cantidad,
                    'precio', pr.precio,
                    'subtotal', (dp.cantidad * pr.precio)
                )
            ) as items
        FROM pedidos p
        LEFT JOIN mesas m ON p.mesa_id = m.id
        JOIN detalles_pedido dp ON dp.pedido_id = p.id
        JOIN productos pr ON dp.producto_id = pr.id
        WHERE p.estado_global = 'Abierto'
        GROUP BY p.id
        ORDER BY p.fecha_hora DESC
    `;
    pool.query(query, (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        const parsed = results.map(r => ({
            ...r,
            items: typeof r.items === 'string' ? JSON.parse(r.items) : r.items
        }));
        res.json(parsed);
    });
});

// 8. POST /api/caja/pedidos/:id/cobrar — Emitir comprobante
app.post('/api/caja/pedidos/:id/cobrar', verificarToken, (req, res) => {
    const { id } = req.params;
    const {
        tipo_comprobante = 'Boleta Simple',
        doc_cliente = '',
        nombre_cliente = 'PÚBLICO GENERAL',
        metodo_pago = 'Efectivo',
        monto_recibido = 0,
        vuelto = 0,
        total = 0
    } = req.body;

    pool.query(`SELECT COUNT(*) as cant FROM comprobantes`, (cErr, cRes) => {
        const num = (cRes && cRes[0].cant) ? cRes[0].cant + 1 : 1;
        const prefijo = tipo_comprobante === 'Factura' ? 'F001' : 'B001';
        const correlativo = `${prefijo}-${String(num).padStart(6, '0')}`;

        const insertSQL = `
            INSERT INTO comprobantes 
            (pedido_id, serie_correlativo, tipo_comprobante, doc_cliente, nombre_cliente, metodo_pago, monto_recibido, vuelto, total)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `;
        pool.query(insertSQL, [id, correlativo, tipo_comprobante, doc_cliente, nombre_cliente, metodo_pago, monto_recibido, vuelto, total], (iErr, iRes) => {
            if (iErr) return res.status(500).json({ error: iErr.message });

            pool.query(`UPDATE pedidos SET estado_global = 'Cerrado' WHERE id = ?`, [id]);
            pool.query(`
                UPDATE mesas m
                JOIN pedidos p ON p.mesa_id = m.id
                SET m.estado = 'Libre'
                WHERE p.id = ?
            `, [id]);

            res.json({
                message: 'Cobro y emisión de boleta exitoso',
                comprobante: {
                    id: iRes.insertId,
                    correlativo,
                    tipo_comprobante,
                    doc_cliente,
                    nombre_cliente,
                    metodo_pago,
                    monto_recibido,
                    vuelto,
                    total,
                    fecha_emision: new Date().toISOString()
                }
            });
        });
    });
});

// 9. GET /api/caja/comprobantes — Historial de boletas
app.get('/api/caja/comprobantes', verificarToken, (req, res) => {
    const query = `
        SELECT 
            c.id,
            c.serie_correlativo,
            c.tipo_comprobante,
            c.doc_cliente,
            c.nombre_cliente,
            c.metodo_pago,
            c.monto_recibido,
            c.vuelto,
            c.total,
            TIME_FORMAT(c.fecha_emision, '%H:%i') as hora,
            DATE_FORMAT(c.fecha_emision, '%d/%m/%Y') as fecha,
            p.nombre_cliente as mesero,
            COALESCE(m.nombre, 'Llevar/Delivery') as mesa
        FROM comprobantes c
        JOIN pedidos p ON c.pedido_id = p.id
        LEFT JOIN mesas m ON p.mesa_id = m.id
        ORDER BY c.fecha_emision DESC
    `;
    pool.query(query, (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results);
    });
});

// 10. GET /api/caja/cierre-preview — Previsualizar Cierre Z
app.get('/api/caja/cierre-preview', verificarToken, (req, res) => {
    // Busca el último cierre para obtener la fecha, si no hay asume todo
    pool.query(`SELECT fecha_cierre FROM cierres_caja ORDER BY id DESC LIMIT 1`, (err, resCierre) => {
        let lastCierre = null;
        if (!err && resCierre && resCierre.length > 0) {
            lastCierre = resCierre[0].fecha_cierre;
        }

        let statsQuery = `
            SELECT 
                COALESCE(SUM(total), 0) as total_ventas,
                COUNT(*) as boletas_emitidas,
                COALESCE(SUM(CASE WHEN metodo_pago = 'Efectivo' THEN total ELSE 0 END), 0) as monto_efectivo,
                COALESCE(SUM(CASE WHEN metodo_pago IN ('Yape', 'Plin') THEN total ELSE 0 END), 0) as monto_yape,
                COALESCE(SUM(CASE WHEN metodo_pago = 'Tarjeta' THEN total ELSE 0 END), 0) as monto_tarjeta
            FROM comprobantes
        `;
        let queryParams = [];
        if (lastCierre) {
            statsQuery += ` WHERE fecha_emision > ?`;
            queryParams.push(lastCierre);
        }

        pool.query(statsQuery, queryParams, (sErr, sRes) => {
            if (sErr) return res.status(500).json({ error: sErr.message });
            res.json(sRes[0]);
        });
    });
});

// 11. POST /api/caja/cierre — Ejecutar Cierre Z
app.post('/api/caja/cierre', verificarToken, (req, res) => {
    const { monto_efectivo, monto_yape, monto_tarjeta, total_ventas, boletas_emitidas } = req.body;
    const cajero = req.usuario.nombre;

    const query = `
        INSERT INTO cierres_caja (cajero_nombre, monto_efectivo, monto_yape, monto_tarjeta, total_ventas, boletas_emitidas)
        VALUES (?, ?, ?, ?, ?, ?)
    `;
    pool.query(query, [cajero, monto_efectivo, monto_yape, monto_tarjeta, total_ventas, boletas_emitidas], (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: 'Cierre de turno ejecutado con éxito', cierre_id: results.insertId });
    });
});

// ══════════════════════════════════════════════════════════════
// RUTAS DE ADMINISTRADOR (ELIMINAR BOLETAS & REPORTES)
// ══════════════════════════════════════════════════════════════

// DELETE /api/admin/comprobantes/:id — ELIMINAR / ANULAR BOLETA
app.delete('/api/admin/comprobantes/:id', verificarToken, verificarAdmin, (req, res) => {
    const { id } = req.params;
    pool.query(`DELETE FROM comprobantes WHERE id = ?`, [id], (err) => {
        if (err) return res.status(500).json({ error: `Error eliminando boleta: ${err.message}` });
        res.json({ message: 'Boleta eliminada correctamente' });
    });
});

// GET /api/admin/ventas-por-fecha — Reporte por fecha
app.get('/api/admin/ventas-por-fecha', verificarToken, verificarAdmin, (req, res) => {
    const fecha = req.query.fecha || new Date().toISOString().split('T')[0];

    const statsSQL = `
        SELECT 
            COALESCE(SUM(total), 0) as ventas_totales,
            COUNT(*) as comprobantes_totales,
            COALESCE(SUM(CASE WHEN metodo_pago = 'Efectivo' THEN total ELSE 0 END), 0) as total_efectivo,
            COALESCE(SUM(CASE WHEN metodo_pago IN ('Yape', 'Plin') THEN total ELSE 0 END), 0) as total_yape,
            COALESCE(SUM(CASE WHEN metodo_pago = 'Tarjeta' THEN total ELSE 0 END), 0) as total_tarjeta
        FROM comprobantes
        WHERE DATE(fecha_emision) = ?
    `;

    const comprobantesSQL = `
        SELECT 
            c.id,
            c.serie_correlativo,
            c.tipo_comprobante,
            c.doc_cliente,
            c.nombre_cliente,
            c.metodo_pago,
            c.monto_recibido,
            c.vuelto,
            c.total,
            TIME_FORMAT(c.fecha_emision, '%H:%i') as hora,
            DATE_FORMAT(c.fecha_emision, '%d/%m/%Y') as fecha,
            p.nombre_cliente as mesero,
            COALESCE(m.nombre, 'Llevar/Delivery') as mesa
        FROM comprobantes c
        JOIN pedidos p ON c.pedido_id = p.id
        LEFT JOIN mesas m ON p.mesa_id = m.id
        WHERE DATE(c.fecha_emision) = ?
        ORDER BY c.fecha_emision DESC
    `;

    pool.query(statsSQL, [fecha], (sErr, sRes) => {
        if (sErr) return res.status(500).json({ error: sErr.message });
        pool.query(comprobantesSQL, [fecha], (cErr, cRes) => {
            if (cErr) return res.status(500).json({ error: cErr.message });
            res.json({
                fecha,
                stats: sRes[0] || { ventas_totales: 0, comprobantes_totales: 0, total_efectivo: 0, total_yape: 0, total_tarjeta: 0 },
                comprobantes: cRes
            });
        });
    });
});

// GET /api/admin/usuarios — Usuarios
app.get('/api/admin/usuarios', verificarToken, verificarAdmin, (req, res) => {
    pool.query(`SELECT id, nombre, usuario, rol, activo, created_at FROM usuarios ORDER BY id ASC`, (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results);
    });
});

// POST /api/admin/usuarios — Crear usuario
app.post('/api/admin/usuarios', verificarToken, verificarAdmin, (req, res) => {
    const { nombre, usuario, password, rol = 'mesero' } = req.body;
    if (!nombre || !usuario || !password) return res.status(400).json({ error: 'Campos requeridos.' });

    pool.query(`INSERT INTO usuarios (nombre, usuario, password, rol, activo) VALUES (?, ?, ?, ?, TRUE)`, [nombre, usuario, password, rol], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: 'Usuario creado', id: result.insertId });
    });
});

// PUT /api/admin/usuarios/:id — Editar usuario
app.put('/api/admin/usuarios/:id', verificarToken, verificarAdmin, (req, res) => {
    const { id } = req.params;
    const { nombre, usuario, password, rol } = req.body;
    if (!nombre || !usuario) return res.status(400).json({ error: 'Nombre y usuario requeridos.' });

    if (password && password.trim() !== '') {
        pool.query(`UPDATE usuarios SET nombre = ?, usuario = ?, password = ?, rol = ? WHERE id = ?`, [nombre, usuario, password, rol, id], (err) => {
            if (err) return res.status(500).json({ error: err.message });
            res.json({ message: 'Usuario actualizado.' });
        });
    } else {
        pool.query(`UPDATE usuarios SET nombre = ?, usuario = ?, rol = ? WHERE id = ?`, [nombre, usuario, rol, id], (err) => {
            if (err) return res.status(500).json({ error: err.message });
            res.json({ message: 'Usuario actualizado.' });
        });
    }
});

// PUT /api/admin/usuarios/:id/estado — Activar/Desactivar
app.put('/api/admin/usuarios/:id/estado', verificarToken, verificarAdmin, (req, res) => {
    const { id } = req.params;
    const { activo } = req.body;
    pool.query(`UPDATE usuarios SET activo = ? WHERE id = ?`, [activo, id], (err) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: 'Estado actualizado.' });
    });
});

// DELETE /api/admin/usuarios/:id — Eliminar usuario
app.delete('/api/admin/usuarios/:id', verificarToken, verificarAdmin, (req, res) => {
    const { id } = req.params;
    pool.query(`DELETE FROM usuarios WHERE id = ?`, [id], (err) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: 'Usuario eliminado.' });
    });
});

// GET /api/admin/productos — Ver platos
app.get('/api/admin/productos', verificarToken, verificarAdmin, (req, res) => {
    const query = `
        SELECT p.id, p.nombre, p.precio, p.disponible, c.id as categoria_id, c.nombre as categoria
        FROM productos p
        JOIN categorias c ON p.categoria_id = c.id
        ORDER BY c.nombre, p.nombre
    `;
    pool.query(query, (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results);
    });
});

// GET /api/admin/categorias — Ver categorías
app.get('/api/admin/categorias', verificarToken, verificarAdmin, (req, res) => {
    pool.query(`SELECT id, nombre FROM categorias ORDER BY nombre`, (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results);
    });
});

// POST /api/admin/productos — Crear plato
app.post('/api/admin/productos', verificarToken, verificarAdmin, (req, res) => {
    const { nombre, precio, categoria_id } = req.body;
    if (!nombre || !precio || !categoria_id) return res.status(400).json({ error: 'Campos requeridos.' });

    pool.query(`INSERT INTO productos (nombre, precio, categoria_id, disponible) VALUES (?, ?, ?, TRUE)`, [nombre, precio, categoria_id], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: 'Plato agregado', id: result.insertId });
    });
});

// PUT /api/admin/productos/:id/estado — Disponibilidad
app.put('/api/admin/productos/:id/estado', verificarToken, verificarAdmin, (req, res) => {
    const { id } = req.params;
    const { disponible } = req.body;
    pool.query(`UPDATE productos SET disponible = ? WHERE id = ?`, [disponible, id], (err) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: 'Disponibilidad actualizada' });
    });
});

// DELETE /api/admin/productos/:id — Eliminar plato
app.delete('/api/admin/productos/:id', verificarToken, verificarAdmin, (req, res) => {
    const { id } = req.params;
    pool.query(`DELETE FROM productos WHERE id = ?`, [id], (err) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: 'Plato eliminado' });
    });
});

// GET /api/admin/stats — Resumen diario
app.get('/api/admin/stats', verificarToken, (req, res) => {
    const query = `
        SELECT 
            COALESCE(SUM(total), 0) as ventas_hoy,
            COUNT(*) as comprobantes_hoy,
            COALESCE(SUM(CASE WHEN metodo_pago = 'Efectivo' THEN total ELSE 0 END), 0) as total_efectivo,
            COALESCE(SUM(CASE WHEN metodo_pago IN ('Yape', 'Plin') THEN total ELSE 0 END), 0) as total_yape,
            COALESCE(SUM(CASE WHEN metodo_pago = 'Tarjeta' THEN total ELSE 0 END), 0) as total_tarjeta
        FROM comprobantes
        WHERE DATE(fecha_emision) = CURDATE()
    `;
    pool.query(query, (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results[0] || { ventas_hoy: 0, comprobantes_hoy: 0, total_efectivo: 0, total_yape: 0, total_tarjeta: 0 });
    });
});

// GET /api/me — Validar sesión activa
app.get('/api/me', verificarToken, (req, res) => {
    res.json({ usuario: req.usuario });
});

// ── Iniciar Servidor ───────────────────────────────────────────

app.use(express.static(path.join(__dirname, 'dist')));

app.use((req, res, next) => {
    if (req.path.startsWith('/api/')) {
        return next();
    }

    res.sendFile(
        path.join(__dirname, 'dist', 'index.html'),
        (err) => {
            if (err) next(err);
        }
    );
});

const PORT = process.env.PORT || 3000;

app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 Don Bigote ejecutándose en el puerto ${PORT}`);
});
